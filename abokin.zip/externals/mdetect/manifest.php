<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'mdetect',
    'version' => '4.1.0',
    'revision' => '$Revision: 7593 $',
    'path' => 'externals/mdetect',
    'repository' => 'socialengine.com',
    'title' => 'mDetect',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/mdetect',
    )
  )
) ?>