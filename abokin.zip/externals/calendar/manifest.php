<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'calendar',
    'version' => '4.0.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/calendar',
    'repository' => 'socialengine.com',
    'title' => 'Calendar',
    'author' => 'Webligo Developments',
    'changeLog' => array(
      '4.0.1' => array(
        'manifest.php' => 'Incremented version',
        'styles.css' => 'Improved localization and RTL support',
      ),
    ),
    'directories' => array(
      'externals/calendar',
    )
  )
) ?>