<?php return array (
  'adapter' => 'system',
  'config' => 
  array (
    'path' => 'C:\\xampp\\htdocs\\abokin',
  ),
)?>